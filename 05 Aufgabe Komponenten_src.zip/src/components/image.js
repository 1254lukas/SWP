import React, { Component } from "react";

import styles from './card.module.css'; 

import logo from './logo.png';

export default class Cards extends Component{
    render(){
        return <div className={styles.border}>
         <img src={logo} alt="Logo" />
        <p className={styles.bold} >John Doe</p>
        <p>Arci&Energ</p>
        </div>
    }
}