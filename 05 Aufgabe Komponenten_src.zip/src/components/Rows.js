import React, { Component } from "react";
 
import Cofe from './cofe.js';
import Bear from './Bear.js';
import Tea from './Tea.js';


export default class Rows extends Component{
    render(){
        return <div >
           <Cofe/>
            <Tea/>
            <Bear/> 
        </div>
    }
}