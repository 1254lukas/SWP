import React, { Component } from "react";
import styles from './rows.module.css'; 

export default class Bears extends Component{
    render(){
        return <div className={styles.button1}>
            <p>Bears</p>
        </div>
    }
}