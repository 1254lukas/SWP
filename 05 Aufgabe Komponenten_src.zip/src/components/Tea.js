import React, { Component } from "react";
import styles from './rows.module.css'; 

export default class Tea extends Component{
    render(){
        return <div className={styles.button1}>
            <p>Tea</p>
        </div>
    }
}