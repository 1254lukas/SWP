import React, { Component } from "react";
import styles from './button.module.css'; 

export default class SuperButton extends Component{
    render(){
        return <div>
            <button  className={styles.green} >Sendar</button>
        </div>
    }
}