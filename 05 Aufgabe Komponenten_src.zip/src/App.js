import './App.css';
import SuperButton from './components/SuperButton';
import Cards from './components/image';
import Rows from './components/Rows';

function App() {
  return (
    <div className="App">
      <h1>Hello!</h1>
        <Rows/>
        <SuperButton/>
     <div>
       <Cards/>
     </div>
    </div>
  );
}

export default App;
