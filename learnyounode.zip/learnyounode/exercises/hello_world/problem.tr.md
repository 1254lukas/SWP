`merhaba-dunya.js` isimli bir dosya oluşturunuz.

Konsol(stdout)a "MERHABA DÜNYA" yazan bir program yazınız.

----------------------------------------------------------------------
## İPUÇLARI

Node.js programı yazabilmek için, `.js` uzantılı bir dosya oluşturmalı ve için JavaScript yazmalısınız! Programınızı çalışmak için `node` komutunu kullanmalısnız. Örneğin;

```sh
$ node merhaba-dunya.js
```

Konsola yazı yazmak tarayıcı da yazı yazmakla aynıdır:

```js
console.log('text')
```

Hazır olduğunuzda aşağıdaki komutu çalıştırınız:

```sh
$ {appname} verify merhaba-dunya.js
```

Bu komut programınızı test edip bir rapor oluşturacaktır, ve eğer problemi çözebildiyseniz bu problem 'tamamlandı' olarak işaretlenecektir.
