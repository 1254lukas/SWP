console.log('こんにちは世界')
