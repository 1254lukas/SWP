/*
var x = 200;
var y = 200;
var color = " #ffff1a";



var canvas = document.getElementById("rechteck");


ctx = canvas.getContext("2d");


quadratDraw(200,200,40);
quadratMove();





function quadratDraw (quadratx,quadraty,seite) 
                                {
                                ctx.clearRect(0, 0, canvas.width, canvas.height);
                                ctx.beginPath();
                                ctx.fillStyle = 'hsla(0, 50%, 50%, 1)';
                                ctx.fillRect(quadratx, quadraty, seite, seite)
                                ctx.stroke();
                                }

function quadratMove()
{
    quadratx = 200;
    quadraty = 200;

   // ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();

for (quadratx > 0; quadratx--;)
        console.log("hier");
       // quadratDraw(x,200,40);	
        
        if (quadratx <= 0)
        {
            quadratx == 400;
        }
        else {

        linie = setInterval(function(){ 

            quadraty--;
           
            ctx.fillStyle = 'hsla(0, 50%, 50%, 1)';
            ctx.fillRect(quadratx, quadraty, 20, 20)
            console.log();
            console.log("hier" +  quadraty );
            ctx.stroke();
            if (y >= 0) {clearInterval(linie); setTimeout(Loeschen, 2000) ; }
            quadratx++;
            }, 30);

        }

}


*/









var x = 200;
var y = 200;
var color = "#fc1703";



var canvas = document.getElementById("rechteck");


ctx = canvas.getContext("2d");
ctx.clearRect(0, 0, canvas.width, canvas.height);

quadratDraw(200,200,20, color);


function quadratDraw (quadratx,quadraty,seite,color) {
                ctx.moveTo(quadratx-1, quadraty);
                ctx.beginPath();
                
                if (quadraty <= 0)
                {quadraty = 400;}
                else
                {


                linie = setInterval(function(){ 

                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.beginPath();
                    console.log("hier" +  quadraty );
                    ctx.fillStyle = 'hsla(0, 50%, 50%, 1)';
                    ctx.fillRect(quadratx, quadraty, seite, seite)
                    ctx.stroke();
                    if (quadraty <= 0) {clearInterval(linie); setTimeout(Loeschen, 2000) ; }
                    quadratx--;
                    }, 30);
                }
                   
}

            

window.addEventListener('keydown', taste, false);


function taste(evt)	{ switch (evt.keyCode) {

                                    case 37:
                                    x=x-10;
                                    if (x < 10)
                                    {x=20; }
                                    quadratDraw(x,y,20,color);
                                    break;

                                    case 38:
                                    y=y-10;
                                    if (y < 10)
                                    {y=20;}
                                    quadratDraw(x,y,20,color);
                                    break;


                                    case 39:
                                    x=x+10;
                                    if (x > 390)
                                    {x=380; }
                                    quadratDraw(x,y,20,color);
                                    break;



                                    case 40: 
                                    y=y+10;
                                    if (y > 390)
                                    {y=380;}
                                    quadratDraw(x,y,20,color);
                                    break;



}





}



function Loeschen () {

	var c = document.getElementById("canvas"); 
	var ctx = c.getContext("2d");
	ctx.fillStyle = "rgba(255, 255, 255, 1)";
	ctx.fillRect(0, 0, canvas.width, -canvas.height);
	ctx.fillStyle = "red";
	ctx.fillRect(200, -10, 10, 10);
	
	}


 


	

	








