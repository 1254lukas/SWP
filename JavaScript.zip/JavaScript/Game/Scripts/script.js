	/*	var x = 200;
		var y = 200;
		var color = " #ffff1a";
		

		
		var canvas = document.getElementById("canvas");


		ctx = canvas.getContext("2d");
		ctx.clearRect(0, 0, canvas.width, canvas.height);

		ballDraw(200,200,20, color);
		

function ballDraw (ballx,bally,r,color) {
										ctx.clearRect(0, 0, canvas.width, canvas.height);
										ctx.beginPath();
										ctx.arc( ballx, bally, r, 0, 360);
										ctx.fillStyle = color;
										ctx.fill();
										ctx.stroke();}


					

window.addEventListener('keydown', taste, false);


function taste(evt)	{ switch (evt.keyCode) {

											case 37:
											x=x-10;
											if (x < 10)
											{x=20; document.getElementById('beep').play();}
											ballDraw(x,y,20,color);
											break;

											case 38:
											y=y-10;
											if (y < 10)
											{y=20; document.getElementById('beep').play();}
											ballDraw(x,y,20,color);
											break;


											case 39:
											x=x+10;
											if (x > 390)
											{x=380; document.getElementById('beep').play();}
											ballDraw(x,y,20,color);
											break;



											case 40: 
											y=y+10;
											if (y > 390)
											{y=380; document.getElementById('beep').play();}
											ballDraw(x,y,20,color);
											break;



	}
	




}


*/