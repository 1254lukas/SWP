import Car from './Car.js'

export default class SuperCar extends Car{
    saySomethingSuperDuper(){
        console.log("super car");
    }
}