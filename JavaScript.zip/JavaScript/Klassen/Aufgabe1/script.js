import Baterie from './Batterie.js';

let c1 = new Baterie("1", 100);



c1.getStatus();
c1.hasPower();
c1.turnOn();
c1.turnOn();
c1.getStatus();
c1.hasPower();


