export default class Baterie{
    // Instanzvariable
    horsePower = 70;
    constructor(id, chargingstatus){
        this.id = id;
        this.chargingstatus = chargingstatus;
       
    }

    printSpecification(){
         console.log(this.id + " - " + this.chargingstatus+"%" );
    }

    getStatus()
    {
        console.log(((c1.chargingstatus + c2.chargingstatus) /2 ) + "%");
    }
    turnOn()
    {   
       c1 = new Baterie("1",(c1.chargingstatus - 5)  );
       c2 = new Baterie("1",(c2.chargingstatus - 5)  );
        c1.printSpecification();
        c2.printSpecification();
    }
    hasPower()
    {
        if ((c1.chargingstatus + c2.chargingstatus) /2 >= 50)
        {
            console.log("true");
            return("true");
        }
        else
        {
            console.log("false");
            return("false");
        }
    }

}

class Person{
    
}

let c1 = new Baterie("1",50, );
let c2 = new Baterie("2",60);
c1.printSpecification();
c2.printSpecification();
