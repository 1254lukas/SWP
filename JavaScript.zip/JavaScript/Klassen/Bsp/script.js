import Person from './Person.js';
import Car from './Car.js';

let p1 = new Person("hansi");
let c1 = new Car("red", "FErrari", 150);

p1.sayHello();
c1.printSpecification();
