var task1 = {name: "putzen", isDone: false, responsible: "Name"}; 
var task2 = {name: "schwimmen", isDone: true, responsible: "Name"}; 


const tasks = [task1, task2]
console.log(tasks);



printTaskList();



//document.getElementById("taskList").innerHTML = tasks;

document.getElementById("addTask").addEventListener("click",function(){
  addTask();
});

function addTask(){
  let taskName = document.getElementById("txtNewTask").value;
  let taskResponsible = document.getElementById("txtResponsible").value;
  let task = {name: taskName, isDone: false,responsible: taskResponsible};
  tasks.push(task);
  printTaskList();
  console.log(tasks);
}

function printTaskList(){
  document.getElementById("taskList").innerHTML = getHTMLTasks();
}


function getHTMLTasks(){
  let html = "";
  tasks.forEach(element => {
    html += "<li>" + element.isDone + "-" + element.name + "-" + element.responsible + "</li>";
  });

  return html;
}