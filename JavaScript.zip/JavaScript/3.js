let banana = "Banane";
let apple = "Apple";
bananaPricePerKilo = 2.14;
applePricePerKilo = 3.43;
let a = 0.34;
let b = 0.22;

console.log( "Anzahl Bananen pro Kilo " + 1.0 / b  );

console.log( "Anzahl Äpfel pro Kilo " + 1.0 / a  );

console.log( "Preis von 8 Äpfeln " + applePricePerKilo * 8  );

console.log( "Preis von 17 Bananen " + bananaPricePerKilo * 17  );

console.log( "Preis von 1 Tonne Äpfel " + applePricePerKilo * (1000/a)  );

console.log( "Preis von 1 Tonne Bananen " + bananaPricePerKilo * (1000/b)   );