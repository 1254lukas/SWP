let urlTeams = 'http://vogis.cnv.at/geoserver/ows?service=WFS&version=1.1.0&request=GetFeature&srsName=EPSG:31254&typeName=vogis:messstellen&outputFormat=application/json&maxFeatures=1000000';


let urlData ='http://vogis.cnv.at/geoserver/ows?service=WFS&version=1.1.0&request=GetFeature&srsName=EPSG:31254&typeName=vogis:niederschlagssumme_jahr&outputFormat=application/json&maxFeatures=1000000';



    fetch(urlTeams, {
        method:"GET",
        
        //headers:{"x-auth-token": "27dd9dde751246b19a9fa67ce9391c45"
    }
)
.then(response => response.json())
.then(function (data) {
    let html=" ";
    data.features.forEach(element => {
        html +="<li>" + element.properties.anlagennam + " in " + element.properties.gemeinde + " : "+"</li>"

    });
    console.log(html);
    document.getElementById("teams").innerHTML = html;
});




fetch(urlData, {
    method:"GET",
    
    //headers:{"x-auth-token": "27dd9dde751246b19a9fa67ce9391c45"
}
)
.then(response => response.json())
.then(function (data) {
let html=" ";
data.features.forEach(element => {
    html +="<li>"  + element.properties.niederschl +"</li>"

});
console.log(html);
document.getElementById("data").innerHTML = html;
});