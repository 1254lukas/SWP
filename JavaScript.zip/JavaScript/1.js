console.log("Tolle Sache");
// Variablen
let a = 7;
let b = 8;
let c = 10;
// Berechne folgendes und gib das Eregebnis über console.log aus
console.log( a + b + c);
console.log((a + b) / c);
console.log(c -a + b);
console.log( a + b + c * 3);
console.log((a + b + c)/4);
// Ändere die Variablen auf folgende Werte
a = 3
b = a + 3
c = c -3
// gib die neuen Werte der Variablen au
console.log("Die geänderten:");
console.log( a );
console.log( b );
console.log( c );