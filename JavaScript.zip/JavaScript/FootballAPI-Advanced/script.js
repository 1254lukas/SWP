
let urlTeams = 'https://api.football-data.org/v2/competitions/2002/teams';






    fetch(urlTeams, {
        method:"GET",
        
        headers:{"x-auth-token": "27dd9dde751246b19a9fa67ce9391c45"
    }
})
.then(response => response.json())
.then(function (data) {
    let html=" <table> ";
    data.teams.forEach(element => {
        html +=  "<tr>" + "<td>" + "<img class='img' src='" + element.crestUrl + "'/>" + "</td>" + "<td>" + element.name  + "</td>" + "<td>" + "<li>" + "<a  href=" + element.website +">" + element.website + "</a>" + "</li>" + "</td>" + "</tr> "

    });
    document.getElementById("teams").innerHTML = html;
    console.log(data.teams);
});




  