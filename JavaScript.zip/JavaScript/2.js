let a = 17.4; 
let b = 3.9;
// Berechne folgendes und gib das Eregebnis über console.log aus
console.log( "The result of " + a + " divided by " +b +" is " + a/b );



let c = "Lukas"; 
let d = "Madlener";
// Berechne folgendes und gib das Eregebnis über console.log aus
console.log( "Ich heiße " + c +" "+ d );
