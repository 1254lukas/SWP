let urlTeams = 'https://api.football-data.org/v2/competitions/2002/teams';






    fetch(urlTeams, {
        method:"GET",
        
        headers:{"x-auth-token": "27dd9dde751246b19a9fa67ce9391c45"
    }
})
.then(response => response.json())
.then(function (data) {
    let html=" ";
    data.teams.forEach(element => {
        html +="<li><img class='img' src='" + element.crestUrl + "'/>" + element.name + "</li>"

    });
    document.getElementById("teams").innerHTML = html;
});