function generate() {
    let num1 = parseInt(document.getElementById("num1").value);
    let num2 = parseInt(document.getElementById("num2").value);
    i = num1;
    p = "<p>" + "Zahlenliste ab Zufälliger Zahl zwischen x und y:  </p>";
    document.getElementById("output").innerHTML = "<p>" + p + "</p>";
    print(i, num2);
}

function print(index, num2) {
    for (i=index;i <= num2; i++) {
        zahlenausgabe = "";
        zahlenausgabe = zahlenausgabe + i;
        p = "<p>" + p + i + "</p>"

        console.log(i);
    
        document.getElementById("output").innerHTML = "<p>" + p + "</p>";
    }
}